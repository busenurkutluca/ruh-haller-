import { useState } from 'react';
import './App.css';
import RuhHalleri from './components/RuhHalleri';

function App() {
  return (
    <>
      <RuhHalleri />
    </>
  );
}

export default App;